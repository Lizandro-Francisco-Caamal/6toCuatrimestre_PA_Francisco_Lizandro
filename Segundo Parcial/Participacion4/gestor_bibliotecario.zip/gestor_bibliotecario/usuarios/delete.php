<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }

    
    $stmt = $conn->prepare("UPDATE usuarios SET activo = 0 WHERE id = ?"); //eliminación lógica
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: index.php?success=" . urlencode("Usuario eliminado con éxito."));
        exit;
    } else {
        $error = $stmt->error;
        $stmt->close();
        $conn->close();
        header("Location: index.php?error=" . urlencode("Error al eliminar el usuario: " . $error));
        exit;
    }
?>