<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $id = intval($_POST["id"] ?? 0);
    $id_usuario = intval($_POST["id_usuario"] ?? 0);
    $fecha_prestamo = trim($_POST["fecha_prestamo"] ?? "");
    $fecha_devolucion = trim($_POST["fecha_devolucion"] ?? "");
    $estado = trim($_POST["estado"] ?? "");
    $id_libro = intval($_POST["id_libro"] ?? 0);
    $cantidad = intval($_POST["cantidad"] ?? 0);

    $estados_validos = ["prestado", "devuelto", "retrasado"];
    $prestamo_valido = DateTime::createFromFormat("Y-m-d", $fecha_prestamo);
    $devolucion_valida = DateTime::createFromFormat("Y-m-d", $fecha_devolucion);

    $fecha_prestamo_valida = $prestamo_valido && $prestamo_valido->format("Y-m-d") === $fecha_prestamo;
    $fecha_devolucion_es_valida = $devolucion_valida && $devolucion_valida->format("Y-m-d") === $fecha_devolucion;

    if (
        $id <= 0 ||
        $id_usuario <= 0 ||
        $id_libro <= 0 ||
        $cantidad <= 0 ||
        !$fecha_prestamo_valida ||
        !$fecha_devolucion_es_valida ||
        !in_array($estado, $estados_validos, true)
    ) {
        header("Location: edit.php?id=" . urlencode($id) . "&error=" . urlencode("Datos inválidos para actualizar el préstamo"));
        exit;
    }

    if ($fecha_devolucion < $fecha_prestamo) {
        header("Location: edit.php?id=" . urlencode($id) . "&error=" . urlencode("La fecha de devolución no puede ser menor a la fecha de préstamo"));
        exit;
    }

    $conn->begin_transaction();

    $stmt = $conn->prepare("UPDATE prestamos SET id_usuario = ?, fecha_prestamo = ?, fecha_devolucion = ?, estado = ? WHERE id = ?");
    $stmt->bind_param("isssi", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado, $id);

    if ($stmt->execute()) {
        $stmt->close();

        $stmt = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id_prestamo = ? LIMIT 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $detalle = $resultado->fetch_assoc();
        $stmt->close();

        if ($detalle) {
            $stmt = $conn->prepare("UPDATE detalle_prestamo SET id_libro = ?, cantidad = ? WHERE id = ?");
            $stmt->bind_param("iii", $id_libro, $cantidad, $detalle["id"]);
            if (!$stmt->execute()) {
                $error = $stmt->error;
                $stmt->close();
                $conn->rollback();
                $conn->close();
                header("Location: edit.php?id=" . urlencode($id) . "&error=" . urlencode("Error al actualizar el detalle del préstamo: " . $error));
                exit;
            }
            $stmt->close();
        } else {
            $stmt = $conn->prepare("INSERT INTO detalle_prestamo (id_prestamo, id_libro, cantidad) VALUES (?, ?, ?)");
            $stmt->bind_param("iii", $id, $id_libro, $cantidad);
            if (!$stmt->execute()) {
                $error = $stmt->error;
                $stmt->close();
                $conn->rollback();
                $conn->close();
                header("Location: edit.php?id=" . urlencode($id) . "&error=" . urlencode("Error al crear el detalle del préstamo: " . $error));
                exit;
            }
            $stmt->close();
        }

        $conn->commit();
        $conn->close();
        header("Location: index.php?success=" . urlencode("Préstamo actualizado exitosamente"));
        exit;
    } else {
        $error = $stmt->error;
        $stmt->close();
        $conn->rollback();
        $conn->close();
        header("Location: edit.php?id=" . urlencode($id) . "&error=" . urlencode("Error al actualizar el préstamo: " . $error));
        exit;
    }
?>